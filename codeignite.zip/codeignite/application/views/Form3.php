<?php
 echo "deleted successfully </br>";
 echo "updated successfully";
 ?>
