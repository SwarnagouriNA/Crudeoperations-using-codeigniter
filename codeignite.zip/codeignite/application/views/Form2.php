
    <html>
       <head>
          <title>Select data from database</title>
       </head>
       <table border="1">
          <tbody>
             <tr>
               <td>ID</td>
                <td>Name</td>
                <td>Phoneno</td>
                <td>Email</td>
                <td>Address</td>
             </tr>
             <?php
             foreach ($h->result() as $row)
             {
                ?><tr>
                  <td><?php echo $row->emp_id;?></td>
                  <td><?php echo $row->emp_name;?></td>
                  <td><?php echo $row->phoneno;?></td>
                  <td><?php echo $row->email_id;?></td>
                  <td><?php echo $row->address;?></td> 
                </tr>
             <?php }
             ?>
          </tbody>
       </table>
    <body>
    </body>
    </html>
