
 <html>
  <head>
  </head>
  <body><center>
    <h2>Enter the data here</h2>
    <form action="checking" method="POST">
      emp_id:  <input type="text" name="emp_id"></br>
      emp_name:<input type="text" name="emp_name"></br>
      phoneno:<input type="text" name="phoneno"></br>
      email_id:<input type="text" name="email_id"></br>
      address:<input type="text" name="address"></br>
      <input type="submit">
    </form>
  </center>
  </body>
</html>
