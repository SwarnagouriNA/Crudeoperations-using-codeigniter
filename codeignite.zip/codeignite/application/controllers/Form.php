
<?php
  class Form extends CI_Controller {
  function __construct()
  {
    parent::__construct();

      $this->load->model('bform');
  }
  public function index()
    {
      $this->load->view('Form1');

    }

    public function checking(){
        print_r($_POST);
        $this->bform->get_all_users($_POST);

        // $data['h']=$this->bform->select();
        //   $this->load->view('Form2', $data);
    }

    public function selecting(){
      $data['h']=$this->bform->select();
        $this->load->view('Form2', $data);
    }

    public function deleting(){
      $this->bform->del();
  	  $this->load->view('Form3');
    }

    public function updating(){
        $this->bform->up();
        $this->load->view('Form3');

    }
  

  }
?>
