<?php
  class Bform extends CI_Model {
    function __construct()
    {
      parent::__construct();
      //$this->load->database("Company");
    }

    public function get_all_users($arr)
    {
       print_r($arr);
       $this->db->insert('Employee', $arr);
       echo "Inserted Successfully";
    }

    public function select(){
      // $this->db->select("emp_id,emp_name,address,phoneno,email_id,count(*)");
      // $this->db->group_by("address");
      $query = $this->db->get('Employee');
          //echo $query;
        return $query;
    }

    public function del(){
      $this->db->where('emp_id',1);
	     return $this->db->delete('Employee');
    }

    public function up(){
      $data=array('emp_id'=>'2',
                  'emp_name'=>'naveen'
                  );
      $this->db->where('emp_id','201820');
      return $this->db->update('Employee',$data);
    }

  }
?>
